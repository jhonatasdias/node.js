/* const products = []; - array method storage data */
const fs = require('fs');
const path = require('path');

module.exports = class Product {
    constructor (title) {
        this.title = title;
    }

    save() {
        /* products.push(this); - array method */
        const p = path.join(path.dirname(process.mainModule.filename), 
        'data', 
        'products.json');
        fs.readFile(p, (err, fileContent) => {
            let products = [];
            if(!err){
                products = JSON.parse(fileContent)
            }
            products.push(this);
            fs.writeFile(p, JSON.stringify(products), (err) => {
                console.log(err);
            })
        });
    }

    static fetchAll(cb) {
        const p = path.join(path.dirname(process.mainModule.filename), 
        'data', 
        'products.json');
        fs.readFile(p, (err, fileContent) => {
            if(err){
                cb([]);
            }
            cb(JSON.parse(fileContent));
        })
    }
}

/* 
- Criando produto, salvando
const p1 = new Product('Book1');
const p2 = new Product('Book2');
p1.save();
p2.save();

const allProducts = Products.fetchAll();

console.log(allProducts);
 */